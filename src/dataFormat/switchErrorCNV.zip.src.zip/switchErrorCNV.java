package dataFormat;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipFile;

public class switchErrorCNV {
	
	//int no_copies=3;
	//static int[] mid={34135863,40527829}; //1
	//static int[] mid={6674263,11769228}; //0
	//static int[] mid={151801138,154499338};
	static int[] mid={60000000,174499338};
	

	   public List<String> getIndiv(ZipFile f, String entryName, Integer column) throws Exception{
	       BufferedReader  nxt = 
	           new BufferedReader(new InputStreamReader(
	           f.getInputStream(f.getEntry(entryName))));
	       List<String> indiv = new ArrayList<String>();
	       String st = "";
	       for(int k=0; (st = nxt.readLine())!=null; k++){
	    	   indiv.add(st.split("\t")[column]);
	       }
	      nxt.close();
	       return indiv;
	   }
	   
	   public static List<String> getSNP(ZipFile f, String entryName) throws Exception{
	       BufferedReader  nxt = 
	           new BufferedReader(new InputStreamReader(
	           f.getInputStream(f.getEntry(entryName))));
	       List<String> snp = new ArrayList<String>();
	       String st = "";
	       while((st = nxt.readLine())!=null){
	    	   String[] str=st.split("\t");
	    	   if(Integer.parseInt(str[1])>=mid[0] && Integer.parseInt(str[2])<=mid[1])
	    	   snp.add(str[3]);
	       }
	      nxt.close();
	       return snp;
	   }
	   
	   //read the missing index file//
	   List<Integer> missingIndex;
	   public void getMissingIndex(File f) throws Exception{
		   missingIndex=new ArrayList<Integer>();
		   BufferedReader br=new BufferedReader(new FileReader(f));
		   String st="";
		   br.readLine(); br.readLine();
		   while((st=br.readLine())!=null){
			   missingIndex.add(Integer.parseInt(st.split("\\s+")[0]));
		   }
	   }
	   
   
	   
	   ////read uncertainty for phasing//
	   Map<String, List<Double>> uncertaintyScore;
	   public Map<String, List<Double>>  getUncertainty(File f)throws Exception{
		   uncertaintyScore=new HashMap<String, List<Double>>();
		   BufferedReader br=new BufferedReader(new FileReader(f));
		   String[] headline=br.readLine().split("\t");
		   for(int i=3; i<headline.length; i+=3){
			   uncertaintyScore.put(headline[i], new ArrayList<Double>());
		   }
		   String st="";
		   while((st = br.readLine())!=null){
			   String[] temp=st.split("\t");
			   for(int i=4; i<headline.length; i+=3){
				   uncertaintyScore.get(headline[i]).add(Double.parseDouble(temp[i]));
			   }
		   }
		   return uncertaintyScore;
	   }
	   
	   //read uncertainty for impute missing data//
	   public Map<String, List<Double>> getUncertaintyImpute(File f)throws Exception{
		   uncertaintyScore=new HashMap<String, List<Double>>();
		   BufferedReader br=new BufferedReader(new FileReader(f));
		   String[] headline=br.readLine().split("\t");
		   for(int i=3; i<headline.length; i+=3){
			   uncertaintyScore.put(headline[i], new ArrayList<Double>());
		   }
		   String st="";
		   while((st = br.readLine())!=null){
			   String[] temp=st.split("\t");
			   for(int i=5; i<headline.length; i+=3){
				  uncertaintyScore.get(headline[i]).add(Double.parseDouble(temp[i].split(":")[0].split("_")[1]));
			   }
		   }
		   return uncertaintyScore;
	   }

	   
	
	//read raw data with known phased from X.zip//
	Map<String, List<Character[]>> rawData;
	Map<String, List<Integer>> rawDataMissing;
	public void getRawData(File f) throws Exception{
		ZipFile zf = new ZipFile(f);
		rawData=new HashMap<String, List<Character[]>>();
		rawDataMissing=new HashMap<String, List<Integer>>();
		List<String> indiv = new ArrayList<String>();
		indiv=getIndiv(zf, "Samples",0);
		List<String> snp = new ArrayList<String>();
		snp=getSNP(zf, "Snps");
		String st = "";
		int count=0;
		for(int i=0; i<snp.size();i++){
			BufferedReader nxt =new BufferedReader(new InputStreamReader(zf.getInputStream(zf.getEntry(snp.get(i)))));
			if(rawData.isEmpty()){
				for(int s=0; s<indiv.size(); s++){
					if((st=nxt.readLine())==null) throw new RuntimeException("!!");
					Character[] temp=new Character[st.length()];
					for(int k=0; k<temp.length; k++){
						temp[k]=st.charAt(k);
					}
					List<Character[]> temp1=new ArrayList<Character[]>();
					List<Integer> temp2=new ArrayList<Integer>();
					temp1.add(temp);
					rawData.put(indiv.get(s), temp1);
					/*if(missingIndex.contains(count)) temp2.add(1); //if missing then==1
					else temp2.add(0); //else ==0
					rawDataMissing.put(indiv.get(s), temp2);
					count++;*/
				}
				//if((st=nxt.readLine())!=null) throw new RuntimeException("!!");
			}
			else{
				for(int s=0; s<indiv.size(); s++){
					if((st=nxt.readLine())==null) throw new RuntimeException("!!");
					Character[] temp=new Character[st.length()];
					for(int k=0; k<temp.length; k++){
						temp[k]=st.charAt(k);
						if(st.charAt(k)=='N') {
							int tt=0;
						}
					}
					rawData.get(indiv.get(s)).add(temp);
					/*if(missingIndex.contains(count)) rawDataMissing.get(indiv.get(s)).add(1); //if missing then==1
					else rawDataMissing.get(indiv.get(s)).add(0); //else ==0
					count++;*/
				}
				//if((st=nxt.readLine())!=null) throw new RuntimeException("!!");
			}
		}
	}
	
	//calculate the counts of the number of copy in all individuals on all sites//
	public int[] getCountCN(File f) throws Exception{
		ZipFile zf = new ZipFile(f);
		List<String> indiv = new ArrayList<String>();
		indiv=getIndiv(zf, "Samples",0);
		List<String> snp = new ArrayList<String>();
		snp=getSNP(zf, "Snps");
		String st = "";
		int[] count=new int[]{0,0,0,0,0};
		int countAAA=0;
		for(int i=0; i<snp.size();i++){
			BufferedReader nxt =new BufferedReader(new InputStreamReader(zf.getInputStream(zf.getEntry(snp.get(i)))));
			for(int s=0; s<indiv.size(); s++){
				if((st=nxt.readLine())==null) throw new RuntimeException("!!");
				//only count hetreozygous site
				String str=st.replaceAll("_", "");
				//if(str.length()==0){
				//	count[0]++;
				//}
				//else{
					//char t=str.charAt(0);
					//for(int k=1; k<str.length(); k++){
					//	if(t!=str.charAt(k)){
							count[str.length()]++;
							if(str.length()==3){
								if(str.equals("AAA") || str.equals("BBB")){
									countAAA++;
								}
							}
					//		break;
					//	}
				//	}

				//}
			}
		}
		System.out.println("AAA="+countAAA);
		int sum=count[0]+count[1]+count[2]+count[3]+count[4];
		return count;
	}
	
	
	
	//read the phased data
	Map<String, String[]> phasedData;
	List<String> phasedIndID;
	public void getPhasedData(File f)throws Exception{
		phasedData=new HashMap<String, String[]>();
		phasedIndID=new ArrayList<String>();
		BufferedReader br = new BufferedReader(new FileReader(f));
		String st=br.readLine();
		while(!st.startsWith("#")){
			st=br.readLine();
		}
		 while(st!=null){
			 if(st.startsWith("#")){
				 String[] str = st.split("\\s+");
				 List<String> te=new ArrayList<String>();
				 st=br.readLine();
				 while(!st.startsWith("#")) {
					 te.add(st);
					 st=br.readLine();
					 if (st==null) break;
				 }
				 String[] temp=new String[te.size()];
				 for(int i=0; i<temp.length; i++){
					 temp[i]=te.get(i);
				 }
				 phasedData.put(str[2].replace("|", ""),temp);
				 phasedIndID.add(str[2].replace('|', ' '));
		     }
		}
	}
	
	
	//get the index of heterozygous sites excluding incorrect genotype prediction//
	int errorPredictGenotype=0;
	public List<Integer> getHeteroIndexCode(String indivID){
		List<Integer> heteroIndex=new ArrayList<Integer>();
		int c3=0;
		int c4=0;
		for(int i=0; i<phasedData.get(indivID)[0].length(); i++){
			List<Character> phase=new ArrayList<Character>();
			List<Character> raw=new ArrayList<Character>();
			for(int k=0; k<2; k++){
				phase.add(phasedData.get(indivID)[k].charAt(i));
				raw.add(rawData.get(indivID).get(i)[k]);
			}
			if(!phase.containsAll(raw) || !raw.containsAll(phase)){
				this.errorPredictGenotype++;
				//for calculate the copy number of error prediction//
				List<String> temp=new ArrayList<String>();
				temp.add(raw.get(0)+""+phase.get(0));
				temp.add(raw.get(1)+""+phase.get(1));
				if(getFromToCopies(temp)==33) c3++;
				else if(getFromToCopies(temp)==44) c4++;
				else throw new RuntimeException("!!");
				//System.out.println("raw:"+raw.get(0)+raw.get(1)+"  phase:"+phase.get(0)+phase.get(1));
			}
			else {
				if(phase.size()!=2) throw new RuntimeException("!!");
				if(phase.get(0)!=phase.get(1)) {
					heteroIndex.add(i);
				}
			}
		}
		System.out.println("3:"+c3+"  4:"+c4);
		return heteroIndex;
	}
	
	//get the index of heterozygous sites //
	public List<Integer> getHeteroIndex(String indivID, int no_copies){
		List<Integer> heteroIndex=new ArrayList<Integer>();
		for(int i=0; i<phasedData.get(indivID)[0].length(); i++){
			char a=phasedData.get(indivID)[0].charAt(i);
			String heter=null;
			for(int k=1; k<no_copies; k++){
				if(phasedData.get(indivID)[k].charAt(i)!=a) heter="yes";
			}
			if(heter!=null) {heteroIndex.add(i);}
		}
		return heteroIndex;
	}
	
	//possible haplotypes for 2 positions//
	List<String> hapSp2=new ArrayList<String>();
	public void getHapSp2(){
		hapSp2.add("AA");
		hapSp2.add("AB");
		hapSp2.add("BA");
		hapSp2.add("BB");
	}
//	possible haplotypes for 3 positions//
	List<String> hapSp3=new ArrayList<String>();
	List<Integer> group1=new ArrayList<Integer>(); 
	List<Integer> group2=new ArrayList<Integer>(); 
	List<Integer> confusedGroup1=new ArrayList<Integer>(); 
	List<Integer> confusedGroup2=new ArrayList<Integer>(); 
	List<Integer> confusedGroup3=new ArrayList<Integer>(); 
	public void getHapSp3(){
		hapSp3.add("AAA");
		hapSp3.add("AAB");
		hapSp3.add("ABA"); //2 confusedGroup1//
		hapSp3.add("BAA");
		hapSp3.add("ABB");
		hapSp3.add("BAB"); //5 confusedGroup1//
		hapSp3.add("BBA");
		hapSp3.add("BBB");
		group1.add(1);group1.add(2);group1.add(3);
		group2.add(4);group2.add(5);group2.add(6);
		confusedGroup1.add(2); confusedGroup1.add(5);
		confusedGroup2.add(1); confusedGroup2.add(6);
		confusedGroup3.add(3); confusedGroup3.add(4);
	}
	
	List<String> hapSp4=new ArrayList<String>();
	List<Integer> group3=new ArrayList<Integer>(); 
	List<Integer> group4=new ArrayList<Integer>();
	List<Integer> group5=new ArrayList<Integer>(); 
	public void getHapSp4(){
		hapSp4.add("AAAA");
		hapSp4.add("AAAB"); hapSp4.add("AABA"); hapSp4.add("ABAA"); hapSp4.add("BAAA");
		hapSp4.add("AABB"); hapSp4.add("ABAB"); hapSp4.add("ABBA"); hapSp4.add("BAAB"); hapSp4.add("BBAA"); hapSp4.add("BABA");
		hapSp4.add("ABBB"); hapSp4.add("BABB"); hapSp4.add("BBAB"); hapSp4.add("BBBA");
		hapSp4.add("BBBB");
		for(int i=1; i<15; i++){
			if(i<5) {group3.add(i);}
			if(i>4 && i<11) {group4.add(i);}
			if(i>10) {group5.add(i);}
		}
	}
	
    public int getSp2Index(String aa){
    	int i=-1;
    	while(i<hapSp2.size()){
    		i++;
    		if(hapSp2.get(i).equals(aa)) break;
    	}
    	return i;
    }
    
    public int getSp2GenoIndex(String aa){
    	int i=-1;
    	while(i<hapSp2.size()){
    		i++;
    		if(hapSp2.get(i).equals(aa)) break;
    	}
    	if(i>1) return i-1;
    	else return i;
    }
    
    public int getSpIndex(List<String> hapSp,String aa){ //get index of haplotype
    	int i=-1;
    	while(i<hapSp.size()){
    		i++;
    		if(hapSp.get(i).equals(aa)) break;
    	}
    	return i;
    }
    

    public List<Integer> getSp3PossibleIndex(int index){ //get three index of three possible haplotypes
    	if(group1.contains(index)){
    		return group1;
    	}
    	else if(group2.contains(index)){
    		return group2;
     	}
    	else throw new RuntimeException("no machted possible Index");
    }
    
    public List<Integer> getSp4PossibleIndex(int index){ //get index of possible haplotypes
    	if(group3.contains(index)){
    		return group3;
    	}
    	else if(group4.contains(index)){
    		return group4;
     	}
    	else if(group5.contains(index)){
    		return group5;
     	}
    	else throw new RuntimeException("no machted possible Index");
    }
    
    //for ambiguous situation for exchanging index//
    Map<Integer, List<byte[]>> possibleExIndex;
    public void getAllPossibleExIndex(){
    	possibleExIndex=new HashMap<Integer, List<byte[]>>();
    	List<byte[]> temp=new ArrayList<byte[]>();
    	temp.add(new byte[]{1,0,3,2}); temp.add(new byte[]{1,2,3,0}); temp.add(new byte[]{3,0,1,2});temp.add(new byte[]{3,2,1,0});
    	possibleExIndex.put(1, temp);
    	temp=new ArrayList<byte[]>();
    	temp.add(new byte[]{2,3,0,1}); temp.add(new byte[]{2,3,1,0}); temp.add(new byte[]{3,2,0,1});temp.add(new byte[]{3,2,1,0});
    	possibleExIndex.put(2, temp);
    	temp=new ArrayList<byte[]>();
    	temp.add(new byte[]{1,0,3,2}); temp.add(new byte[]{1,3,0,2}); temp.add(new byte[]{2,0,3,1}); temp.add(new byte[]{2,3,0,1});
    	possibleExIndex.put(3, temp);
    }
    
    public int getAmbigousIndex(List<Integer> index){
    	int amIndex=0;
    	List<Integer> temp=new ArrayList<Integer>();
    	temp.add(6); temp.add(10);
    	if (index.containsAll(temp)) {
    		amIndex=1;
    	}
    	temp=new ArrayList<Integer>();
    	temp.add(5); temp.add(9);
    	if (index.containsAll(temp)) {
    		amIndex=2;
    	}
    	temp=new ArrayList<Integer>();
    	temp.add(7); temp.add(8);
    	if (index.containsAll(temp)) {
    		amIndex=3;
    	}
    	return amIndex;
    }
    
    
    //for fisr two positions/
    public List<String> getHapFromPhasedData(String indivID, int i,List<Integer> heteroIndex, Integer hapSpIndex, int noIndex, List<String> hapSp){ 
    	                                                                               //noIndex is how many snps to form a hapltoype//
    	List<String> inferHap=new ArrayList<String>();
    	for(int k=0; k<phasedData.get(indivID).length; k++){  //get haplotypes from phased data//
    		char[] temp=new char[noIndex];
    		int count=noIndex-1;
    		for(int n=0; n<noIndex-1; n++){
    			temp[n]=phasedData.get(indivID)[k].charAt(heteroIndex.get(i-count));
    			count--;
    		}
    		temp[noIndex-1]=hapSp.get(hapSpIndex).charAt(k);
			String s = new String(temp);
			inferHap.add(s);
		}
    	return inferHap;
    }
    
    //for after fisr two positions// //get haplotypes hap space//
   public List<String> getHapFromIndex(int[] hapSpIndex, List<String> hapSp, int no_copies){
    	List<String> inferHap=new ArrayList<String>();
    	for(int i=0; i<no_copies; i++){
    		char[] temp=new char[hapSpIndex.length];
    		for(int k=0; k<hapSpIndex.length; k++){
    			temp[k]=hapSp.get(hapSpIndex[k]).charAt(i);
    		}
    		String s = new String(temp);
    		inferHap.add(s);
    	}
    	return inferHap;
    }
    
    //get the string of genotype of position i from phased data//
    public String getGenotypeString(String indivID, int i,List<Integer> heteroIndex){
    	char[] geno=new char[phasedData.get(indivID).length];
    	for(int k=0; k<geno.length; k++){
    		geno[k]=phasedData.get(indivID)[k].charAt(heteroIndex.get(i));
    	}
    	String s = new String(geno);
        return s;
    }
    
    //get the string of 3 alleles of position i from raw data//
    public String getGenoStringSwiched(String indivID, int i,List<Integer> heteroIndex, List<byte[]> newIndexTrueHap){
    	char[] geno=new char[phasedData.get(indivID).length];
    	for(int k=0; k<geno.length; k++){
    		geno[k]=phasedData.get(indivID)[newIndexTrueHap.get(i)[k]].charAt(heteroIndex.get(i));
    	}
    	String s = new String(geno);
        return s;
    }
    

    
    public List<byte[]> getExchangeIndex(String a1, String a2, List<byte[]> newIndexTrueHapList, int no_copies){
    	byte[] newIndexTrueHap=new byte[3];
    	byte[] dif=new byte[2];
    	byte c=0;
		for(byte i=0; i<no_copies; i++){
    		if(a1.charAt(i)!=a2.charAt(i)) {
    			dif[c]=i;
    			c++;
    		}
    	}
		for(byte i=0; i<no_copies; i++){
			if(i==dif[0]) newIndexTrueHap[i]=dif[1];
			else if(i==dif[1]) newIndexTrueHap[i]=dif[0];
			else newIndexTrueHap[i]=i;
		}
        //update previous index//
		List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
		if(!newIndexTrueHapList.isEmpty()){
	    	for(int k=0; k<newIndexTrueHapList.size(); k++){
	    		byte[] newIndexTrueHap1=new byte[3];
	    		for(int i=0; i<no_copies; i++){
	    			if(i==dif[0]) newIndexTrueHap1[i]=newIndexTrueHapList.get(k)[dif[1]];
	    			else if(i==dif[1]) newIndexTrueHap1[i]=newIndexTrueHapList.get(k)[dif[0]];
	    			else newIndexTrueHap1[i]=newIndexTrueHapList.get(k)[i];
	    		}
	    		newIndexTrueHapList1.add(newIndexTrueHap1);
	    	}
		}

    	newIndexTrueHapList1.add(newIndexTrueHap);
		return newIndexTrueHapList1;
    }
    
    //for tetraploid//
    public List<byte[]> getExchangeIndex4(String a1, String a2, List<byte[]> newIndexTrueHapList, int no_copies){
    	byte[] newIndexTrueHap=new byte[no_copies];
    	byte[] dif=new byte[2];
    	byte c=0;
		for(byte i=0; i<no_copies; i++){
    		if(a1.charAt(i)!=a2.charAt(i)) {
    			dif[c]=i;
    			c++;
    		}
    	}
		for(byte i=0; i<no_copies; i++){
			if(i==dif[0]) newIndexTrueHap[i]=dif[1];
			else if(i==dif[1]) newIndexTrueHap[i]=dif[0];
			else newIndexTrueHap[i]=i;
		}
        //update previous index//
		List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
		if(!newIndexTrueHapList.isEmpty()){
	    	for(int k=0; k<newIndexTrueHapList.size(); k++){
	    		byte[] newIndexTrueHap1=new byte[no_copies];
	    		for(int i=0; i<no_copies; i++){
	    			if(i==dif[0]) newIndexTrueHap1[i]=newIndexTrueHapList.get(k)[dif[1]];
	    			else if(i==dif[1]) newIndexTrueHap1[i]=newIndexTrueHapList.get(k)[dif[0]];
	    			else newIndexTrueHap1[i]=newIndexTrueHapList.get(k)[i];
	    		}
	    		newIndexTrueHapList1.add(newIndexTrueHap1);
	    	}
		}

    	newIndexTrueHapList1.add(newIndexTrueHap);
		return newIndexTrueHapList1;
    }
    
    //for tetraploid, when there are more than one possible way to change index between two gemotypes//
    public List<byte[]> getExchangeIndexAll(byte[] onePossible, List<byte[]> newIndexTrueHapList, int no_copies){
    	List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
    	for(int k=0; k<newIndexTrueHapList.size(); k++){
    		byte[] newIndexTrueHap1=new byte[no_copies];
    		for(int i=0; i<no_copies; i++){
    			newIndexTrueHap1[i]=newIndexTrueHapList.get(k)[onePossible[i]];
    		}
    		newIndexTrueHapList1.add(newIndexTrueHap1);
    	}
    	newIndexTrueHapList1.add(onePossible);
    	return newIndexTrueHapList1;
    }
    
    //to count how many different haplotyes//
    public int getNoDiffHap(int[] hapSpIndex, List<String> hapSp, int no_copies){
    	List<String> hapList=this.getHapFromIndex(hapSpIndex, hapSp, no_copies);
    	List<String> newHapList=new ArrayList<String>();
    	for(int i=0; i<hapList.size(); i++){
    		if(!newHapList.contains(hapList.get(i))) newHapList.add(hapList.get(i));
    	}
    	int noDiffHap=newHapList.size();
    	return noDiffHap;
    }
    
    public int[] getA2B2count(String indivID, List<String> hapSp, int no_copies){
    	int count=0;
    	List<Integer> heteroIndex=getHeteroIndex(indivID, no_copies);
    	for(int i=0; i<heteroIndex.size(); i++){
    		if(group4.contains(getSpIndex(hapSp,this.getGenotypeString(indivID, i, heteroIndex)))) count++;
    	}
    	int[] ratio=new int[]{count,heteroIndex.size()};
    	return ratio;
    }
    
    List<String> majorAllele;
    public void getMajorAllel(File f)throws Exception{
    	majorAllele=new ArrayList<String>();
    	BufferedReader br = new BufferedReader(new FileReader(f));
		String st;
	    while((st = br.readLine())!=null){
	    	String[] str=st.split("\t");
	    	if(Integer.parseInt(str[1])>=mid[0] && Integer.parseInt(str[2])<=mid[1])
	    	majorAllele.add(str[4]);
	    }
    }
    
   
    //get the number of copies from one position to the other position//
    public int getFromToCopies(List<String> inferHap){ //12->means from 1 copy to 2 copies
    	int from=0;
    	int to=0;
    	for(int i=0; i<inferHap.size(); i++){
    		if(inferHap.get(i).charAt(0)=='A' || inferHap.get(i).charAt(0)=='B') from+=1; 
    		if(inferHap.get(i).charAt(0)=='X' || inferHap.get(i).charAt(0)=='Y' || inferHap.get(i).charAt(0)=='Z') from+=2;
    		if(inferHap.get(i).charAt(0)=='U' || inferHap.get(i).charAt(0)=='V' || inferHap.get(i).charAt(0)=='W' || inferHap.get(i).charAt(0)=='T') from+=3;
    	}
    	for(int i=0; i<inferHap.size(); i++){
    		if(inferHap.get(i).charAt(1)=='A' || inferHap.get(i).charAt(1)=='B') to+=1; 
    		if(inferHap.get(i).charAt(1)=='X' || inferHap.get(i).charAt(1)=='Y' || inferHap.get(i).charAt(1)=='Z') to+=2;
    		if(inferHap.get(i).charAt(1)=='U' || inferHap.get(i).charAt(1)=='V' || inferHap.get(i).charAt(1)=='W' || inferHap.get(i).charAt(1)=='T') to+=3;
    	}
    	if(from==0 || to==0) throw new RuntimeException("!!");
    	return from*10+to; //ex:2*10+3....2copies->3copies
    }

	public int[] getSwitchError(String indivID){
		if(rawData.get(indivID).size()!=phasedData.get(indivID)[0].length()) {
			throw new RuntimeException(phasedData.get(indivID)[0].length()+"# of snp on phasedHap !="+rawData.get(indivID).size()+ "# of snp on rawData");
		}
		int no_copies=phasedData.get(indivID).length;
		List<Integer> heteroIndex=getHeteroIndexCode(indivID);
		//List<Integer> boundaryIndex=getBoundaryIndex(indivID, heteroIndex);
		int switchError=0;
		errorHeteroIndex.put(indivID, new Integer[3][heteroIndex.size()]);
		errorHeteroIndex.get(indivID)[0]=(Integer[])heteroIndex.toArray(new Integer[0]);
		Arrays.fill(errorHeteroIndex.get(indivID)[1], 0);
		Arrays.fill(errorHeteroIndex.get(indivID)[2], 0);
		Map<String,List<byte[]>> newIndexTrueHapList=new HashMap<String, List<byte[]>>(); //store the new order of true hap after switch--possible 1//
		for(int i=1; i<heteroIndex.size(); i++){
			if(no_copies==2){
				List<String> trueHap=new ArrayList<String>();
				List<String> inferHap=new ArrayList<String>();
				for(int k=0; k<no_copies; k++){ 
					char[] temp={rawData.get(indivID).get(heteroIndex.get(i-1))[k], rawData.get(indivID).get(heteroIndex.get(i))[k]};
					String s = new String(temp);
					trueHap.add(s);
				}
				for(int k=0; k<no_copies; k++){ 
					char[] temp={phasedData.get(indivID)[k].charAt(heteroIndex.get(i-1)), phasedData.get(indivID)[k].charAt(heteroIndex.get(i))};
					String s = new String(temp);
					inferHap.add(s);
				}
				//if(this.getFromToCopies(inferHap)==33) {
				//	int tt=0;
					//this.getFromToCopies(inferHap);
				//}
				if(!trueHap.containsAll(inferHap) || !inferHap.containsAll(trueHap)){
					switchError++;
					errorHeteroIndex.get(indivID)[1][i]=1;
					errorHeteroIndex.get(indivID)[2][i]=this.getFromToCopies(inferHap);//for the index of 1->2 copies or 1->3 copies or.....
				}
			}
			if(no_copies==3){
				if(i==1){
					List<String> trueHap=new ArrayList<String>();
                    //get 3 haplotypes, like AA, AB, BA, or BB from original data//
					for(int k=0; k<no_copies; k++){ 
						char[] temp={rawData.get(indivID).get(heteroIndex.get(i-1))[k], rawData.get(indivID).get(heteroIndex.get(i))[k]};
						String s = new String(temp);
						trueHap.add(s);
					}
//					get index of 3 alleles (genotype) in the hapSpace for i poistion//
					Integer hapSpIndex=getSpIndex(hapSp3,this.getGenotypeString(indivID, i, heteroIndex));
					
					List<String> inferHap=this.getHapFromPhasedData(indivID, i, heteroIndex, hapSpIndex, 2, hapSp3);
					
					int p=0;
					if(!trueHap.containsAll(inferHap) || !inferHap.containsAll(trueHap)){
						switchError++;
						errorHeteroIndex.get(indivID)[1][i]=1;
						List<Integer> possibleIndex=getSp3PossibleIndex(hapSpIndex);
						for(int h=0; h<possibleIndex.size(); h++){
							if(possibleIndex.get(h)!=hapSpIndex){
								inferHap=this.getHapFromPhasedData(indivID, i, heteroIndex, possibleIndex.get(h), 2, hapSp3);
								if(trueHap.containsAll(inferHap)){
									List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
									newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList1);
									newIndexTrueHapList.put(i+"_"+p, this.getExchangeIndex(hapSp3.get(hapSpIndex), hapSp3.get(possibleIndex.get(h)), newIndexTrueHapList.get(i+"_"+p), no_copies));
									p++;
								}
							}
						}
					}
					else {
						List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
						newIndexTrueHapList1.add(new byte[]{0,1,2});
						newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList1);
					}
				}
				else{
					String check=null;
					int p=0;
					String switchErrorSign=null;
					List<String> tempIterator=new ArrayList<String>();
					for(Iterator<String> is=newIndexTrueHapList.keySet().iterator(); is.hasNext();){
						String st=is.next();
						tempIterator.add(st);
					}
					//if(tempIterator.size()>1) {
					//	System.out.print("2");
					//}
					for(int t=0; t<tempIterator.size();t++){
						String st=tempIterator.get(t);
	 					//get 3 alleles for i poistion----phased hapltoyeps//
						Integer hapSpIndex1=getSpIndex(hapSp3,this.getGenotypeString(indivID, i, heteroIndex)); //from phased data//
						Integer hapSpIndex2=getSpIndex(hapSp3,this.getGenotypeString(indivID, i-1, heteroIndex)); 
						Integer hapSpIndex3=getSpIndex(hapSp3,this.getGenoStringSwiched(indivID, i-2, heteroIndex, newIndexTrueHapList.get(st)));
						//get the index for the third position if necessary//
						int newIndex=i-2;
						for(int ji=i-3; ji>=0; ji--){
							List<Integer> temp=new ArrayList<Integer>();
							temp.add(hapSpIndex2); temp.add(hapSpIndex3);
							if(temp.containsAll(confusedGroup1) || temp.containsAll(confusedGroup2) || temp.containsAll(confusedGroup3) || hapSpIndex2==hapSpIndex3){
								hapSpIndex3=getSpIndex(hapSp3,this.getGenoStringSwiched(indivID, ji, heteroIndex, newIndexTrueHapList.get(st)));
								newIndex=ji;
							}
							else break;
					    }
						//get true haplotypes//
						List<String> trueHap=new ArrayList<String>();
						for(int k=0; k<no_copies; k++){ //get 3 haplotypes, like AAA, ABA, BAA, BBA.... from original data//
							char[] temp={rawData.get(indivID).get(heteroIndex.get(newIndex))[k], rawData.get(indivID).get(heteroIndex.get(i-1))[k], rawData.get(indivID).get(heteroIndex.get(i))[k]};
							String s = new String(temp);
							trueHap.add(s);
						}
						//for phased data//
						List<String> inferHap=this.getHapFromIndex(new int[]{hapSpIndex3, hapSpIndex2, hapSpIndex1}, hapSp3, no_copies);
						
						if(!trueHap.containsAll(inferHap) || !inferHap.containsAll(trueHap)){
							List<Integer> possibleIndex=getSp3PossibleIndex(hapSpIndex1);
							for(int h=0; h<possibleIndex.size(); h++){
								if(possibleIndex.get(h)!=hapSpIndex1){
									inferHap=this.getHapFromIndex(new int[]{hapSpIndex3, hapSpIndex2, possibleIndex.get(h)}, hapSp3, no_copies);
									if(trueHap.containsAll(inferHap)){
										newIndexTrueHapList.put(i+"_"+p, this.getExchangeIndex(hapSp3.get(hapSpIndex1), hapSp3.get(possibleIndex.get(h)), newIndexTrueHapList.get(st), no_copies));
										check="ok";
										p++;
									}

								}
							}
						}
						else {
							newIndexTrueHapList.get(st).add(new byte[]{0,1,2});
							newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList.get(st));
							check="ok";
							p++;
							switchErrorSign="-"; //which means no switcherror//
						}
						newIndexTrueHapList.remove(st);
					}
					if(check==null) throw new RuntimeException(i+"th true haps and phase haps are not matched");
					if(switchErrorSign==null) {
						switchError++;
						errorHeteroIndex.get(indivID)[1][i]=1;
					}
				}
			}
			if(no_copies==4){
				if(i==1){
					String check=null;
					List<String> trueHap=new ArrayList<String>();
                    //get 4 haplotypes, like AA, AB, BA, or BB from original data//
					for(int k=0; k<no_copies; k++){ 
						char[] temp={rawData.get(indivID).get(heteroIndex.get(i-1))[k], rawData.get(indivID).get(heteroIndex.get(i))[k]};
						String s = new String(temp);
						trueHap.add(s);
					}
					//get index of 4 alleles (genotype) in the hapSpace for i poistion//
					Integer hapSpIndex=getSpIndex(hapSp4,this.getGenotypeString(indivID, i, heteroIndex));

					List<String> inferHap=this.getHapFromPhasedData(indivID, i, heteroIndex, hapSpIndex, 2, hapSp4);
					
					int p=0;
					if(!trueHap.containsAll(inferHap) || !inferHap.containsAll(trueHap)){
						switchError++;
						errorHeteroIndex.get(indivID)[1][i]=1;
						List<Integer> possibleIndex=getSp4PossibleIndex(hapSpIndex);
						for(int h=0; h<possibleIndex.size(); h++){
							if(possibleIndex.get(h)!=hapSpIndex){
								inferHap=this.getHapFromPhasedData(indivID, i, heteroIndex, possibleIndex.get(h), 2, hapSp4);
								if(trueHap.containsAll(inferHap)){
									List<Integer> index2=new ArrayList<Integer>();
									index2.add(hapSpIndex);index2.add(possibleIndex.get(h));
									int amIndex=getAmbigousIndex(index2);
									if(possibleExIndex.containsKey(amIndex)){
										for(int k=0; k<possibleExIndex.get(amIndex).size(); k++){
											List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
											newIndexTrueHapList1.add(possibleExIndex.get(amIndex).get(k));
											newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList1);
											p++; //this mean that it might have different switch to recover the true hap//
											check="ok";
											//break;
										}
									}
									else{
										List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
										newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList1);
										newIndexTrueHapList.put(i+"_"+p, this.getExchangeIndex4(hapSp4.get(hapSpIndex), hapSp4.get(possibleIndex.get(h)), newIndexTrueHapList.get(i+"_"+p), no_copies));
										p++; //this mean that it might have different switch to recover the true hap//
										check="ok";
									}
								}
							}
						}
					}
					else {
						List<byte[]> newIndexTrueHapList1=new ArrayList<byte[]>();
						newIndexTrueHapList1.add(new byte[]{0,1,2,3});
						newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList1);
						check="ok";
					}
					if(check==null) throw new RuntimeException(i+"the true haps and phase haps are not matched");
				}
				else if(i==2){
					String check=null;
					int p=0;
					String switchErrorSign=null;
					List<String> tempIterator=new ArrayList<String>();
					for(Iterator<String> is=newIndexTrueHapList.keySet().iterator(); is.hasNext();){
						String st=is.next();
						tempIterator.add(st);
					}
					//if(tempIterator.size()>1) {
					//	System.out.print("2");
					//}
					for(int t=0; t<tempIterator.size();t++){
						String st=tempIterator.get(t);
	 					//get 4 alleles for i poistion----phased hapltoyeps//
						Integer hapSpIndex1=getSpIndex(hapSp4,this.getGenotypeString(indivID, i, heteroIndex)); //from phased data//
						Integer hapSpIndex2=getSpIndex(hapSp4,this.getGenotypeString(indivID, i-1, heteroIndex)); 
						Integer hapSpIndex3=getSpIndex(hapSp4,this.getGenoStringSwiched(indivID, i-2, heteroIndex, newIndexTrueHapList.get(st)));
						//get true haplotypes//
						List<String> trueHap=new ArrayList<String>();
						for(int k=0; k<no_copies; k++){ //get 3 haplotypes, like AAA, ABA, BAA, BBA.... from original data//
							char[] temp={rawData.get(indivID).get(heteroIndex.get(i-2))[k], rawData.get(indivID).get(heteroIndex.get(i-1))[k], rawData.get(indivID).get(heteroIndex.get(i))[k]};
							String s = new String(temp);
							trueHap.add(s);
						}
						//for phased data//
						List<String> inferHap=this.getHapFromIndex(new int[]{hapSpIndex3, hapSpIndex2, hapSpIndex1}, hapSp4, no_copies);
						if(!trueHap.containsAll(inferHap) || !inferHap.containsAll(trueHap)){
							List<Integer> possibleIndex=getSp4PossibleIndex(hapSpIndex1);
							for(int h=0; h<possibleIndex.size(); h++){
								if(possibleIndex.get(h)!=hapSpIndex1){
									inferHap=this.getHapFromIndex(new int[]{hapSpIndex3, hapSpIndex2, possibleIndex.get(h)}, hapSp4, no_copies);
									if(trueHap.containsAll(inferHap)){
										List<Integer> index2=new ArrayList<Integer>();
										index2.add(hapSpIndex1);index2.add(possibleIndex.get(h));
										int amIndex=getAmbigousIndex(index2);
										if(possibleExIndex.containsKey(amIndex)){
											for(int k=0; k<possibleExIndex.get(amIndex).size(); k++){
												newIndexTrueHapList.put(i+"_"+p, this.getExchangeIndexAll(possibleExIndex.get(amIndex).get(k), newIndexTrueHapList.get(st), no_copies));
												check="ok";
												p++;
												//break;
											}
										}
										else{
											newIndexTrueHapList.put(i+"_"+p, this.getExchangeIndex4(hapSp4.get(hapSpIndex1), hapSp4.get(possibleIndex.get(h)), newIndexTrueHapList.get(st), no_copies));
											check="ok";
											p++;

										}
									}

								}
							}
						}
						else {
							newIndexTrueHapList.get(st).add(new byte[]{0,1,2,3});
							newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList.get(st));
							check="ok";
							p++;
							switchErrorSign="-"; //which means no switcherror//
						}
						newIndexTrueHapList.remove(st);
					}
					if(check==null) {
						throw new RuntimeException(i+"th true haps and phase haps are not matched");
					}
					if(switchErrorSign==null) {
						switchError++;
						errorHeteroIndex.get(indivID)[1][i]=1;
					}
				}
				else{
					String check=null;
					int p=0;
					String switchErrorSign=null;
					List<String> tempIterator=new ArrayList<String>();
					for(Iterator<String> is=newIndexTrueHapList.keySet().iterator(); is.hasNext();){
						String st=is.next();
						tempIterator.add(st);
					}
				   // if(indivID.equals("WTCCC66361")) {
					//	System.out.print("2");
					//}
					for(int t=0; t<tempIterator.size();t++){
						String st=tempIterator.get(t);
	 					//get 3 alleles for i poistion----phased hapltoyeps//
						Integer hapSpIndex1=getSpIndex(hapSp4,this.getGenotypeString(indivID, i, heteroIndex)); //from phased data//
						Integer hapSpIndex2=getSpIndex(hapSp4,this.getGenotypeString(indivID, i-1, heteroIndex)); 
						Integer hapSpIndex3=getSpIndex(hapSp4,this.getGenoStringSwiched(indivID, i-2, heteroIndex, newIndexTrueHapList.get(st)));
						//to check if the third position is informative enough//
						int newIndex3=i-2;
						for(int ji=i-3; ji>0; ji--){
							int noDiffHap=getNoDiffHap(new int[]{hapSpIndex3, hapSpIndex2}, hapSp4, no_copies);
							if(noDiffHap<3) {
								hapSpIndex3=getSpIndex(hapSp4,this.getGenoStringSwiched(indivID, ji, heteroIndex, newIndexTrueHapList.get(st)));
								newIndex3=ji;
							}
							else break;
					    }
                        //to check if the fourth position is informative enough//
						int newIndex4=newIndex3-1;
						Integer hapSpIndex4=getSpIndex(hapSp4,this.getGenoStringSwiched(indivID, newIndex4, heteroIndex, newIndexTrueHapList.get(st)));
						for(int ji=newIndex3-2; ji>=0; ji--){
							int noDiffHap=getNoDiffHap(new int[]{hapSpIndex4, hapSpIndex3, hapSpIndex2}, hapSp4, no_copies);
							if(noDiffHap<4) {
								hapSpIndex4=getSpIndex(hapSp4,this.getGenoStringSwiched(indivID, ji, heteroIndex, newIndexTrueHapList.get(st)));
								newIndex4=ji;
							}
							else break;
					    }
						//get true haplotypes from original data//
						List<String> trueHap=new ArrayList<String>();
						for(int k=0; k<no_copies; k++){ 
							char[] temp={rawData.get(indivID).get(heteroIndex.get(newIndex4))[k],rawData.get(indivID).get(heteroIndex.get(newIndex3))[k], 
									     rawData.get(indivID).get(heteroIndex.get(i-1))[k], rawData.get(indivID).get(heteroIndex.get(i))[k]};
							String s = new String(temp);
							trueHap.add(s);
						}
						//for phased data//
						List<String> inferHap=this.getHapFromIndex(new int[]{hapSpIndex4, hapSpIndex3, hapSpIndex2, hapSpIndex1}, hapSp4, no_copies);
						
						if(!trueHap.containsAll(inferHap) || !inferHap.containsAll(trueHap)){
							List<Integer> possibleIndex=getSp4PossibleIndex(hapSpIndex1);
							for(int h=0; h<possibleIndex.size(); h++){
								if(possibleIndex.get(h)!=hapSpIndex1){
									inferHap=this.getHapFromIndex(new int[]{hapSpIndex4, hapSpIndex3, hapSpIndex2,possibleIndex.get(h)}, hapSp4, no_copies);
									if(trueHap.containsAll(inferHap)){
										List<Integer> index2=new ArrayList<Integer>();
										index2.add(hapSpIndex1); index2.add(possibleIndex.get(h));
										int amIndex=getAmbigousIndex(index2);
										if(possibleExIndex.containsKey(amIndex)){
											for(int k=0; k<possibleExIndex.get(amIndex).size(); k++){
												newIndexTrueHapList.put(i+"_"+p, this.getExchangeIndexAll(possibleExIndex.get(amIndex).get(k), newIndexTrueHapList.get(st), no_copies));
												check="ok";
												p++;
												//break;
											}
										}
										else{
											newIndexTrueHapList.put(i+"_"+p, this.getExchangeIndex4(hapSp4.get(hapSpIndex1), hapSp4.get(possibleIndex.get(h)), newIndexTrueHapList.get(st), no_copies));
											check="ok";
											p++;

										}
									}

								}
							}
						}
						else {
							newIndexTrueHapList.get(st).add(new byte[]{0,1,2,3});
							newIndexTrueHapList.put(i+"_"+p, newIndexTrueHapList.get(st));
							check="ok";
							p++;
							switchErrorSign="-"; //which means no switcherror//
						}
						newIndexTrueHapList.remove(st);
					}
					if(check==null) {
						throw new RuntimeException(i+"th true haps and phase haps are not matched");
					}
					if(switchErrorSign==null) {
						switchError++;
						errorHeteroIndex.get(indivID)[1][i]=1;
					}
				}
			}
		}
		int[] switchCounts=new int[]{switchError,heteroIndex.size()};
		newIndexTrueHapList.clear();
		return switchCounts;
	}

	//using silly method...compare each position of happlotype with true hap to find the most likely corresponding ture hap//
	public double getIncorrectRate(String indivID){ 
		int no_copies=phasedData.get(indivID).length;
		List<Integer> heteroIndex=this.getHeteroIndex(indivID, no_copies);
		double[] incorrectRate=new double[no_copies];
		int[][] countDif=new int[no_copies][no_copies];
		for(int i=0; i<countDif.length; i++){
			Arrays.fill(countDif[i], 0);
			Arrays.fill(countDif[i], 0);
		}
		for(int i=0; i<no_copies; i++){ 
			for(int t=0; t<no_copies; t++){
				for(int m=0; m<heteroIndex.size(); m++){ //count the difference//
					if(phasedData.get(indivID)[i].charAt(heteroIndex.get(m))!=rawData.get(indivID).get(heteroIndex.get(m))[t]) {
						countDif[i][t]++;
					}
				}
			}
		}
		for(int i=0; i<no_copies; i++){
			int min=Integer.MAX_VALUE;
			for(int k=0; k<countDif[i].length; k++){
				if(countDif[i][k]<min) min=countDif[i][k];
			}
			incorrectRate[i]=(double)min/(double)heteroIndex.size();
		}
		double temp=0.0;
		for(int i=0; i<no_copies; i++){
			temp=temp+incorrectRate[i];
		}
		return temp/no_copies;
	}
	
	//for trisomy data...get the number of loci which has different alleles between two strains// 
	public Map<String, Integer> getNumDiff(){
		Map<String, Integer> numDiff=new HashMap<String, Integer>();
		for(Iterator<String> is=phasedData.keySet().iterator();is.hasNext();){
			String indivID=is.next();
			int[] count=new int[]{0,0,0};
			for(int i=0; i<phasedData.get(indivID)[0].length(); i++){
				if(phasedData.get(indivID)[0].charAt(i)!=phasedData.get(indivID)[1].charAt(i)) count[0]++;
				if(phasedData.get(indivID)[0].charAt(i)!=phasedData.get(indivID)[2].charAt(i)) count[1]++;
				if(phasedData.get(indivID)[1].charAt(i)!=phasedData.get(indivID)[2].charAt(i)) count[2]++;
			}
			int min=count[0];
			for(int i=1; i<count.length; i++){
				if(count[i]<min) min=count[i];
			}
			numDiff.put(indivID, min);
		}
		return numDiff;
	}
	
	//for trisomy data...for raw data...get the number of loci which has different alleles between two strains// 
	public Map<String, Integer> getNumDiffRaw(){
		Map<String, Integer> numDiff=new HashMap<String, Integer>();
		for(Iterator<String> is=this.rawData.keySet().iterator();is.hasNext();){
			String indivID=is.next();
			int[] count=new int[]{0,0,0};
			for(int i=0; i<rawData.get(indivID).size(); i++){
				if(rawData.get(indivID).get(i)[0]!=rawData.get(indivID).get(i)[1]) count[0]++;
				if(rawData.get(indivID).get(i)[0]!=rawData.get(indivID).get(i)[2]) count[1]++;
				if(rawData.get(indivID).get(i)[1]!=rawData.get(indivID).get(i)[2]) count[2]++;
			}
			int min=count[0];
			for(int i=1; i<count.length; i++){
				if(count[i]<min) min=count[i];
			}
			numDiff.put(indivID, min);
		}
		return numDiff;
	}
	
	public void printNumDiff(PrintStream ps){
		Map<String, Integer> numDiff=this.getNumDiffRaw();
		for(Iterator<String> is=numDiff.keySet().iterator();is.hasNext();){
			String indivID=is.next();
		    ps.print(indivID+"  ");ps.println(numDiff.get(indivID));
		}
	}
	
	
	public void printErrorRate(PrintStream ps, Map<String, Double> rate){
		double sum=0;
		for(Iterator<String> id=rate.keySet().iterator();id.hasNext();){
			String idv=id.next();
			//int[] a2b2=this.getA2B2count(idv, hapSp4);
			sum=sum+rate.get(idv);
			ps.print(idv); ps.print("---"); ps.println(rate.get(idv));
			//ps.print("---"); ps.print(a2b2[0]);ps.print("/"); ps.print(a2b2[1]); ps.print("---"); ps.println(a2b2[0]/a2b2[1]);
		}
		ps.print("averge:"); ps.println((double)sum/(double)switchErrortateAll.size());
	}
	
	
	//compare uncertainty with switch error////
	//Map<Integer, Integer[][]> countError=new HashMap<Integer, Integer[][]>();
	public Map<Integer, int[][]>  compareUncerSwitch(){
		   Map<Integer, int[][]> fromToCertainty=new HashMap<Integer, int[][]>();
		   int sum=0;
		   for(Iterator<String> is=errorHeteroIndex.keySet().iterator();is.hasNext();){
				String indivID=is.next();
				Integer[][] count=errorHeteroIndex.get(indivID);
				sum+=count[0].length;
				for(int i=0; i<count[0].length; i++){
					double certainty=uncertaintyScore.get(indivID).get(count[0][i]);
					Integer a=count[2][i];
					if(!fromToCertainty.containsKey(a)) {
						int[][] countError=new int[2][10];
						Arrays.fill(countError[0], 0);
						Arrays.fill(countError[1], 0);
						fromToCertainty.put(a,countError);
					}
					for(int k=1; k<11; k++){
						if(certainty*100<=(double)k*10) {
							fromToCertainty.get(a)[1][k-1]++;
							break;
						}
					}
					if(count[1][i]==1){
						for(int k=1; k<11; k++){
							if(certainty*100<=(double)k*10) {
								fromToCertainty.get(a)[0][k-1]++;
								break;
							}
						}
					}
				}
		   }
		   int[][] countError=new int[1][1];
		   countError[0][0]=sum;
		   fromToCertainty.put(0, countError);
		   return fromToCertainty;
	}
	
	//compare a snp between phase data and raw data//
	public int comparePhaseRaw(String[] phase, List<Character[]> raw, int pos){
			   int[] phasedCount={0,0}; //[A,B]
			   int[] rawCount={0,0}; //[A,B]
				for(int c=0; c<phase.length; c++){
					if (phase[c].charAt(pos)=='A') phasedCount[0]++;
					else phasedCount[1]++;
					if(raw.get(pos)[c].equals('A')) rawCount[0]++;
					else rawCount[1]++;
				}
				if(phasedCount[0]!=rawCount[0] || phasedCount[1]!=rawCount[1]) return 1; //unmatched ==1
				else return 0; //matched==0
	}
	
	   //compare impute error rate and certainty rate//
	//Map<Integer, Integer[][]> countErrorImpute=new HashMap<Integer, Integer[][]>();
	   public int[][] compareUncerImpute(){
		   int[][] countError=new int[2][10];
			Arrays.fill(countError[0], 0);
			Arrays.fill(countError[1], 0);
			for(Iterator<String> id=rawDataMissing.keySet().iterator();id.hasNext();){
				String idv=id.next();
				for(int i=0; i<rawDataMissing.get(idv).size(); i++){
					if(rawDataMissing.get(idv).get(i)==1){
						//System.out.println(idv+"---"+i);
						double certainty=uncertaintyScore.get(idv).get(i);
						for(int k=1; k<11; k++){
							if(certainty*100<=(double)k*10) {
								countError[1][k-1]++;
								break;
							}
						}
						if(this.comparePhaseRaw(phasedData.get(idv), rawData.get(idv), i)==1){
							for(int k=1; k<11; k++){
								if(certainty*100<=(double)k*10) {
									countError[0][k-1]++;
									break;
								}
							}
						}

					}
				}
			}
			return countError;
	   }

	   
	   //get the counts of error of fromToCoies...1->2, 1->3....after calculating switch error rate
	   public Map<Integer, Integer> getCountFromTo(){
		   Map<Integer, Integer> fromToCount=new HashMap<Integer, Integer>();
		   int sum=0;
		   for(Iterator<String> is=errorHeteroIndex.keySet().iterator();is.hasNext();){
				String indivID=is.next();
				Integer[][] count=errorHeteroIndex.get(indivID);
				sum+=count[0].length;
				for(int i=0; i<count[0].length; i++){
					Integer a=count[2][i];
					if(a!=0) {
						if(count[1][i]==0) throw new RuntimeException("!!");
						if(!fromToCount.containsKey(a)) fromToCount.put(a,1);
						else {
							Integer newCount=fromToCount.get(a)+1;
							fromToCount.put(a, newCount);
						}
					}
				}
		   }
		   fromToCount.put(0, sum);
		   return fromToCount;
	   }
	   
	   //get the counts of fromToCoies...1->2, 1->3....all of pair heterozygous in the data
	   public Map<Integer, Integer> getCountFromToTotal(){
		   Map<Integer, Integer> fromToCount=new HashMap<Integer, Integer>();
		   int sum=0;
		   for(Iterator<String> is=phasedData.keySet().iterator();is.hasNext();){
				String indivID=is.next();
				List<Integer> heteroIndex=getHeteroIndexCode(indivID);
				for(int i=1; i<heteroIndex.size(); i++){
					int no_copies=2;
					sum++;
						List<String> inferHap=new ArrayList<String>();
						for(int k=0; k<no_copies; k++){ 
							char[] temp={phasedData.get(indivID)[k].charAt(heteroIndex.get(i-1)), phasedData.get(indivID)[k].charAt(heteroIndex.get(i))};
							String s = new String(temp);
							inferHap.add(s);
						}
						int a=this.getFromToCopies(inferHap);//for the index of 1->2 copies or 1->3 copies or.....
						if(a!=0) {
							if(!fromToCount.containsKey(a)) fromToCount.put(a,1);
							else {
								Integer newCount=fromToCount.get(a)+1;
								fromToCount.put(a, newCount);
							}
						}
						else {
							System.out.println(inferHap.get(0)+":"+inferHap.get(1));
						}
				}
		   }
		   fromToCount.put(0, sum);
		   return fromToCount;
	   }

	   
	   public void printOutCount(PrintStream ps){
		   Map<Integer, Integer> fromToCount=this.getCountFromTo();
		   int sum=fromToCount.get(0);
		   double check=0;
		   for(Iterator<Integer> is=fromToCount.keySet().iterator();is.hasNext();){
			   Integer fromTo=is.next();
			   ps.println(fromTo+":"+(double)fromToCount.get(fromTo)/sum);
			   check+=(double)fromToCount.get(fromTo)/sum;
		   }
		   System.out.print(check);
	   }
	   
	   public void printOutCount1(PrintStream ps){
		   Map<Integer, Integer> fromToCount=this.getCountFromTo();
		   Map<Integer, Integer> fromToCountTotal=this.getCountFromToTotal();
		   int sum=fromToCount.get(0);
		   for(Iterator<Integer> is=fromToCountTotal.keySet().iterator();is.hasNext();){
			   Integer fromTo=is.next();
			   if(!fromToCount.containsKey(fromTo)) {
				   ps.println(fromTo+":0"+"  counts:"+ fromToCountTotal.get(fromTo)+"   rate:"+(double)fromToCountTotal.get(fromTo)/(double)sum);
			   }
			   else ps.println(fromTo+":"+(double)fromToCount.get(fromTo)/(double)fromToCountTotal.get(fromTo)+
					   "  counts:"+ fromToCountTotal.get(fromTo)+"   rate:"+(double)fromToCountTotal.get(fromTo)/(double)sum);
		   }
	   }

	
	
	Map<String,Double> switchErrortateAll;
	List<Double> incorrectRateAll;
	Map<String, Integer[][]> errorHeteroIndex;
	
	//take average within an individual//
	public void run(){
		errorHeteroIndex=new HashMap<String, Integer[][]>();
		switchErrortateAll=new HashMap<String, Double>();
		incorrectRateAll=new ArrayList<Double>();
		for(Iterator<String> is=phasedData.keySet().iterator();is.hasNext();){
			String indivID=is.next();
			//String indivID="WTCCC66151";
			int[] count=getSwitchError(indivID);
			switchErrortateAll.put(indivID,(double)count[0]/(double)count[1]);
			incorrectRateAll.add(this.getIncorrectRate(indivID));
		}
	}
	
	//across all dataset and individual//
	Map<Integer, Integer> noSwitchAll=new HashMap<Integer, Integer>();
	Map<Integer, Integer> noHeteroSiteAll=new HashMap<Integer, Integer>();
	public void run1(){
		errorHeteroIndex=new HashMap<String, Integer[][]>();
		for(Iterator<String> is=phasedData.keySet().iterator();is.hasNext();){
			String indivID=is.next();
			int no_copies=phasedData.get(indivID).length;
			if(no_copies!=1){
				int[] count=getSwitchError(indivID);
				if(!noSwitchAll.containsKey(no_copies)){
					noSwitchAll.put(no_copies, count[0]);
					noHeteroSiteAll.put(no_copies, count[1]);
				}
				else{
					noSwitchAll.put(no_copies, noSwitchAll.get(no_copies)+count[0]);
					noHeteroSiteAll.put(no_copies, noHeteroSiteAll.get(no_copies)+count[1]);
				}
			}
		}
	}
	
	public void printErrorRate1(PrintStream ps){
		for(Iterator<Integer> in=noSwitchAll.keySet().iterator();in.hasNext();){
			Integer no=in.next();
			double rate=(double)noSwitchAll.get(no)/(double)noHeteroSiteAll.get(no);
			ps.println("no_copies: "+ no);
			ps.println(rate);
			ps.println(Math.sqrt(rate*(1-rate)/(double)noHeteroSiteAll.get(no)));
		}
		ps.println("errorPredictGenotype:" + this.errorPredictGenotype);

	}
	

	public void printCompareUncerSwi(PrintStream ps, int count[][]) {
		for(int i=0; i<count[0].length; i++){
			if(count[0][i]!=0){
				ps.print((double)(i+1)/10+"\t"); 
				ps.print((double)count[0][i]/(double)count[1][i]+"\t"); 
				ps.println((double)count[1][i]/(double)noHeteroSiteAll.get(2)); //for switch error rate
			}
		}
	}
	
	
	public static void main(String[] args) {
		try {
				switchErrorCNV se=new switchErrorCNV();
				se.getHapSp2();
				se.getHapSp3();
				se.getHapSp4(); 
				se.getAllPossibleExIndex();
				
				se.getCountCN(new File("X.zip"));

					se.getRawData(new File("Xtrue.zip"));
					se.getPhasedData(new File("phased2_10")); 
					se.getUncertainty(new File("phased1_10"));
					se.run1(); //run for switch error rate
			    PrintStream ps=new PrintStream(new BufferedOutputStream(new FileOutputStream(new File("switchErrorRate_10"+".txt"))));
			    se.printErrorRate1(ps);
				ps.close();
				PrintStream ps1=new PrintStream(new BufferedOutputStream(new FileOutputStream(new File("switchErrorRateFromToTotal_10"+".txt"))));
			    se.printOutCount1(ps1);
				ps1.close();
				
                //for uncertainty switch//
				Map<Integer, int[][]> count=se.compareUncerSwitch(); 
				for(Iterator<Integer> in=count.keySet().iterator();in.hasNext();){
					Integer index=in.next();
					if(index!=0){
						PrintStream ps2=new PrintStream(new BufferedOutputStream(new FileOutputStream(new File("compareUncerSwitch10"+"_"+index+".txt"))));
					    se.printCompareUncerSwi(ps2, count.get(index));
						ps2.close();
					}
				}

				
		} catch (Exception exc) {
			exc.printStackTrace();
		}
	}



}
